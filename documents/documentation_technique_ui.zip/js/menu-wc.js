'use strict';


customElements.define('compodoc-menu', class extends HTMLElement {
    constructor() {
        super();
        this.isNormalMode = this.getAttribute('mode') === 'normal';
    }

    connectedCallback() {
        this.render(this.isNormalMode);
    }

    render(isNormalMode) {
        let tp = lithtml.html(`
        <nav>
            <ul class="list">
                <li class="title">
                    <a href="index.html" data-type="index-link">really-worth-site documentation</a>
                </li>

                <li class="divider"></li>
                ${ isNormalMode ? `<div id="book-search-input" role="search"><input type="text" placeholder="Type to search"></div>` : '' }
                <li class="chapter">
                    <a data-type="chapter-link" href="index.html"><span class="icon ion-ios-home"></span>Getting started</a>
                    <ul class="links">
                        <li class="link">
                            <a href="overview.html" data-type="chapter-link">
                                <span class="icon ion-ios-keypad"></span>Overview
                            </a>
                        </li>
                        <li class="link">
                            <a href="index.html" data-type="chapter-link">
                                <span class="icon ion-ios-paper"></span>README
                            </a>
                        </li>
                        <li class="link">
                            <a href="changelog.html"  data-type="chapter-link">
                                <span class="icon ion-ios-paper"></span>CHANGELOG
                            </a>
                        </li>
                        <li class="link">
                            <a href="license.html"  data-type="chapter-link">
                                <span class="icon ion-ios-paper"></span>LICENSE
                            </a>
                        </li>
                                <li class="link">
                                    <a href="dependencies.html" data-type="chapter-link">
                                        <span class="icon ion-ios-list"></span>Dependencies
                                    </a>
                                </li>
                    </ul>
                </li>
                    <li class="chapter modules">
                        <a data-type="chapter-link" href="modules.html">
                            <div class="menu-toggler linked" data-toggle="collapse" ${ isNormalMode ?
                                'data-target="#modules-links"' : 'data-target="#xs-modules-links"' }>
                                <span class="icon ion-ios-archive"></span>
                                <span class="link-name">Modules</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                        </a>
                        <ul class="links collapse " ${ isNormalMode ? 'id="modules-links"' : 'id="xs-modules-links"' }>
                            <li class="link">
                                <a href="modules/AppModule.html" data-type="entity-link">AppModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-AppModule-ce0aee0afc6acda8601a85ec28a79509"' : 'data-target="#xs-components-links-module-AppModule-ce0aee0afc6acda8601a85ec28a79509"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-AppModule-ce0aee0afc6acda8601a85ec28a79509"' :
                                            'id="xs-components-links-module-AppModule-ce0aee0afc6acda8601a85ec28a79509"' }>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/InitialRedirectComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">InitialRedirectComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-AppModule-ce0aee0afc6acda8601a85ec28a79509"' : 'data-target="#xs-injectables-links-module-AppModule-ce0aee0afc6acda8601a85ec28a79509"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-AppModule-ce0aee0afc6acda8601a85ec28a79509"' :
                                        'id="xs-injectables-links-module-AppModule-ce0aee0afc6acda8601a85ec28a79509"' }>
                                        <li class="link">
                                            <a href="injectables/RecipientBadgeApiService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>RecipientBadgeApiService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/AuthModule.html" data-type="entity-link">AuthModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-AuthModule-8fef31fc51f8056ac4f5e2db422ff852"' : 'data-target="#xs-components-links-module-AuthModule-8fef31fc51f8056ac4f5e2db422ff852"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-AuthModule-8fef31fc51f8056ac4f5e2db422ff852"' :
                                            'id="xs-components-links-module-AuthModule-8fef31fc51f8056ac4f5e2db422ff852"' }>
                                            <li class="link">
                                                <a href="components/LoginComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoginComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LogoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LogoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/OAuth2AuthorizeComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">OAuth2AuthorizeComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RequestPasswordResetComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">RequestPasswordResetComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ResetPasswordComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ResetPasswordComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ResetPasswordSent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ResetPasswordSent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/WelcomeComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">WelcomeComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/BadgrCommonModule.html" data-type="entity-link">BadgrCommonModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' : 'data-target="#xs-components-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' :
                                            'id="xs-components-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' }>
                                            <li class="link">
                                                <a href="components/BadgeImageComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeImageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgrButtonComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgrButtonComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BgBadgecard.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgBadgecard</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BgBreadcrumbsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgBreadcrumbsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BgFormFieldFileComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgFormFieldFileComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BgFormFieldImageComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgFormFieldImageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BgIssuerLinkComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgIssuerLinkComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BgPopupMenu.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgPopupMenu</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ConfirmDialog.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ConfirmDialog</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ConnectedBadgeComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ConnectedBadgeComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ExternalToolLaunchComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ExternalToolLaunchComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FormFieldMarkdown.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FormFieldMarkdown</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FormFieldRadio.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FormFieldRadio</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FormFieldSelect.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FormFieldSelect</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FormFieldText.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FormFieldText</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FormMessageComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FormMessageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ForwardRouteComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ForwardRouteComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoadingDotsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoadingDotsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoadingErrorComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoadingErrorComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MarkdownDisplay.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MarkdownDisplay</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MarkdownHintsDialog.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MarkdownHintsDialog</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NewTermsDialog.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NewTermsDialog</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/OAuthBannerComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">OAuthBannerComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ShareSocialDialog.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ShareSocialDialog</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ShowMore.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ShowMore</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/SvgIconComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">SvgIconComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/TimeComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">TimeComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/TooltipComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">TooltipComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/TruncatedTextComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">TruncatedTextComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#directives-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' : 'data-target="#xs-directives-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' }>
                                        <span class="icon ion-md-code-working"></span>
                                        <span>Directives</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="directives-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' :
                                        'id="xs-directives-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' }>
                                        <li class="link">
                                            <a href="directives/AutosizeDirective.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules">AutosizeDirective</a>
                                        </li>
                                        <li class="link">
                                            <a href="directives/BgAwaitPromises.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgAwaitPromises</a>
                                        </li>
                                        <li class="link">
                                            <a href="directives/BgCopyInputDirective.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgCopyInputDirective</a>
                                        </li>
                                        <li class="link">
                                            <a href="directives/BgImageStatusPlaceholderDirective.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgImageStatusPlaceholderDirective</a>
                                        </li>
                                        <li class="link">
                                            <a href="directives/BgMarkdownComponent.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules">BgMarkdownComponent</a>
                                        </li>
                                        <li class="link">
                                            <a href="directives/MenuItemDirective.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules">MenuItemDirective</a>
                                        </li>
                                        <li class="link">
                                            <a href="directives/ScrollPinDirective.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules">ScrollPinDirective</a>
                                        </li>
                                    </ul>
                                </li>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#pipes-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' : 'data-target="#xs-pipes-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' }>
                                            <span class="icon ion-md-add"></span>
                                            <span>Pipes</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="pipes-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' :
                                            'id="xs-pipes-links-module-BadgrCommonModule-c4e3cc4f7d3d3b52737e599673684c0b"' }>
                                            <li class="link">
                                                <a href="pipes/UcFirstPipe.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">UcFirstPipe</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/CommonEntityManagerModule.html" data-type="entity-link">CommonEntityManagerModule</a>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-CommonEntityManagerModule-de5d2b42b94c3fe02b862126b1ae92fc"' : 'data-target="#xs-injectables-links-module-CommonEntityManagerModule-de5d2b42b94c3fe02b862126b1ae92fc"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-CommonEntityManagerModule-de5d2b42b94c3fe02b862126b1ae92fc"' :
                                        'id="xs-injectables-links-module-CommonEntityManagerModule-de5d2b42b94c3fe02b862126b1ae92fc"' }>
                                        <li class="link">
                                            <a href="injectables/CommonEntityManager.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>CommonEntityManager</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/IssuerModule.html" data-type="entity-link">IssuerModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-IssuerModule-d26fb82c3c05f2a3afd8c99ac0e39897"' : 'data-target="#xs-components-links-module-IssuerModule-d26fb82c3c05f2a3afd8c99ac0e39897"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-IssuerModule-d26fb82c3c05f2a3afd8c99ac0e39897"' :
                                            'id="xs-components-links-module-IssuerModule-d26fb82c3c05f2a3afd8c99ac0e39897"' }>
                                            <li class="link">
                                                <a href="components/BadgeClassCreateComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeClassCreateComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeClassDetailComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeClassDetailComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeClassEditComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeClassEditComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeClassEditFormComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeClassEditFormComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeClassIssueBulkAwardComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeClassIssueBulkAwardComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeClassIssueBulkAwardImportComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeClassIssueBulkAwardImportComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeClassIssueBulkAwardPreviewComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeClassIssueBulkAwardPreviewComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeClassIssueComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeClassIssueComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeSelectionDialog.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeSelectionDialog</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeStudioComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeStudioComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeclassIssueBulkAwardConformation.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeclassIssueBulkAwardConformation</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgeclassIssueBulkAwardError.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgeclassIssueBulkAwardError</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/IssuerCreateComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">IssuerCreateComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/IssuerDetailComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">IssuerDetailComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/IssuerEditComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">IssuerEditComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/IssuerListComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">IssuerListComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/IssuerStaffComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">IssuerStaffComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/IssuerStaffCreateDialogComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">IssuerStaffCreateDialogComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-IssuerModule-d26fb82c3c05f2a3afd8c99ac0e39897"' : 'data-target="#xs-injectables-links-module-IssuerModule-d26fb82c3c05f2a3afd8c99ac0e39897"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-IssuerModule-d26fb82c3c05f2a3afd8c99ac0e39897"' :
                                        'id="xs-injectables-links-module-IssuerModule-d26fb82c3c05f2a3afd8c99ac0e39897"' }>
                                        <li class="link">
                                            <a href="injectables/BadgeClassApiService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>BadgeClassApiService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/BadgeClassManager.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>BadgeClassManager</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/BadgeInstanceApiService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>BadgeInstanceApiService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/BadgeInstanceManager.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>BadgeInstanceManager</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/IssuerApiService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>IssuerApiService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/IssuerManager.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>IssuerManager</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/MozzTransitionModule.html" data-type="entity-link">MozzTransitionModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-MozzTransitionModule-3ea32e4032b811da5da4f31d5d977d08"' : 'data-target="#xs-components-links-module-MozzTransitionModule-3ea32e4032b811da5da4f31d5d977d08"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-MozzTransitionModule-3ea32e4032b811da5da4f31d5d977d08"' :
                                            'id="xs-components-links-module-MozzTransitionModule-3ea32e4032b811da5da4f31d5d977d08"' }>
                                            <li class="link">
                                                <a href="components/ImportModalComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ImportModalComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#directives-links-module-MozzTransitionModule-3ea32e4032b811da5da4f31d5d977d08"' : 'data-target="#xs-directives-links-module-MozzTransitionModule-3ea32e4032b811da5da4f31d5d977d08"' }>
                                        <span class="icon ion-md-code-working"></span>
                                        <span>Directives</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="directives-links-module-MozzTransitionModule-3ea32e4032b811da5da4f31d5d977d08"' :
                                        'id="xs-directives-links-module-MozzTransitionModule-3ea32e4032b811da5da4f31d5d977d08"' }>
                                        <li class="link">
                                            <a href="directives/ImportLauncherDirective.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules">ImportLauncherDirective</a>
                                        </li>
                                        <li class="link">
                                            <a href="directives/SourceListenerDirective.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules">SourceListenerDirective</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/ProfileModule.html" data-type="entity-link">ProfileModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-ProfileModule-8a471eb0bef4e4b58ef322e85aee823c"' : 'data-target="#xs-components-links-module-ProfileModule-8a471eb0bef4e4b58ef322e85aee823c"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-ProfileModule-8a471eb0bef4e4b58ef322e85aee823c"' :
                                            'id="xs-components-links-module-ProfileModule-8a471eb0bef4e4b58ef322e85aee823c"' }>
                                            <li class="link">
                                                <a href="components/AppIntegrationListComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppIntegrationListComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BadgebookLti1DetailComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BadgebookLti1DetailComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ChangePasswordComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ChangePasswordComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/IntegrationImageComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">IntegrationImageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/OAuthAppDetailComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">OAuthAppDetailComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ProfileComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ProfileComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ProfileEditComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ProfileEditComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-ProfileModule-8a471eb0bef4e4b58ef322e85aee823c"' : 'data-target="#xs-injectables-links-module-ProfileModule-8a471eb0bef4e4b58ef322e85aee823c"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-ProfileModule-8a471eb0bef4e4b58ef322e85aee823c"' :
                                        'id="xs-injectables-links-module-ProfileModule-8a471eb0bef4e4b58ef322e85aee823c"' }>
                                        <li class="link">
                                            <a href="injectables/AppIntegrationApiService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>AppIntegrationApiService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/AppIntegrationManager.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>AppIntegrationManager</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/UserProfileApiService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>UserProfileApiService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/UserProfileManager.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>UserProfileManager</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/PublicModule.html" data-type="entity-link">PublicModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-PublicModule-e8b2d86ab6882d9f30dd043033f0d4af"' : 'data-target="#xs-components-links-module-PublicModule-e8b2d86ab6882d9f30dd043033f0d4af"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-PublicModule-e8b2d86ab6882d9f30dd043033f0d4af"' :
                                            'id="xs-components-links-module-PublicModule-e8b2d86ab6882d9f30dd043033f0d4af"' }>
                                            <li class="link">
                                                <a href="components/PublicBadgeAssertionComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">PublicBadgeAssertionComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/PublicBadgeClassComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">PublicBadgeClassComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/PublicBadgeCollectionComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">PublicBadgeCollectionComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/PublicComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">PublicComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/PublicIssuerComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">PublicIssuerComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/VerifyBadgeDialog.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">VerifyBadgeDialog</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-PublicModule-e8b2d86ab6882d9f30dd043033f0d4af"' : 'data-target="#xs-injectables-links-module-PublicModule-e8b2d86ab6882d9f30dd043033f0d4af"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-PublicModule-e8b2d86ab6882d9f30dd043033f0d4af"' :
                                        'id="xs-injectables-links-module-PublicModule-e8b2d86ab6882d9f30dd043033f0d4af"' }>
                                        <li class="link">
                                            <a href="injectables/PublicApiService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>PublicApiService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/RecipientModule.html" data-type="entity-link">RecipientModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-RecipientModule-430a14563eb2f994aadd78f93ad4df02"' : 'data-target="#xs-components-links-module-RecipientModule-430a14563eb2f994aadd78f93ad4df02"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-RecipientModule-430a14563eb2f994aadd78f93ad4df02"' :
                                            'id="xs-components-links-module-RecipientModule-430a14563eb2f994aadd78f93ad4df02"' }>
                                            <li class="link">
                                                <a href="components/AddBadgeDialogComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AddBadgeDialogComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RecipientBadgeCollectionCreateComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">RecipientBadgeCollectionCreateComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RecipientBadgeCollectionDetailComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">RecipientBadgeCollectionDetailComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RecipientBadgeCollectionEditFormComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">RecipientBadgeCollectionEditFormComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RecipientBadgeCollectionListComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">RecipientBadgeCollectionListComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RecipientBadgeCollectionSelectionDialogComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">RecipientBadgeCollectionSelectionDialogComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RecipientBadgeSelectionDialog.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">RecipientBadgeSelectionDialog</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RecipientEarnedBadgeDetailComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">RecipientEarnedBadgeDetailComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RecipientEarnedBadgeListComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">RecipientEarnedBadgeListComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-RecipientModule-430a14563eb2f994aadd78f93ad4df02"' : 'data-target="#xs-injectables-links-module-RecipientModule-430a14563eb2f994aadd78f93ad4df02"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-RecipientModule-430a14563eb2f994aadd78f93ad4df02"' :
                                        'id="xs-injectables-links-module-RecipientModule-430a14563eb2f994aadd78f93ad4df02"' }>
                                        <li class="link">
                                            <a href="injectables/RecipientBadgeApiService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>RecipientBadgeApiService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/RecipientBadgeCollectionApiService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>RecipientBadgeCollectionApiService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/RecipientBadgeCollectionManager.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>RecipientBadgeCollectionManager</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/RecipientBadgeManager.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>RecipientBadgeManager</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/SignupModule.html" data-type="entity-link">SignupModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-SignupModule-a5346a7993890c0361c2af8a9a890260"' : 'data-target="#xs-components-links-module-SignupModule-a5346a7993890c0361c2af8a9a890260"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-SignupModule-a5346a7993890c0361c2af8a9a890260"' :
                                            'id="xs-components-links-module-SignupModule-a5346a7993890c0361c2af8a9a890260"' }>
                                            <li class="link">
                                                <a href="components/SignupComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">SignupComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/SignupSuccessComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">SignupSuccessComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-SignupModule-a5346a7993890c0361c2af8a9a890260"' : 'data-target="#xs-injectables-links-module-SignupModule-a5346a7993890c0361c2af8a9a890260"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-SignupModule-a5346a7993890c0361c2af8a9a890260"' :
                                        'id="xs-injectables-links-module-SignupModule-a5346a7993890c0361c2af8a9a890260"' }>
                                        <li class="link">
                                            <a href="injectables/SignupService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>SignupService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                </ul>
                </li>
                        <li class="chapter">
                            <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#directives-links"' :
                                'data-target="#xs-directives-links"' }>
                                <span class="icon ion-md-code-working"></span>
                                <span>Directives</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                            <ul class="links collapse " ${ isNormalMode ? 'id="directives-links"' : 'id="xs-directives-links"' }>
                                <li class="link">
                                    <a href="directives/BgPopupMenuTriggerDirective.html" data-type="entity-link">BgPopupMenuTriggerDirective</a>
                                </li>
                            </ul>
                        </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#classes-links"' :
                            'data-target="#xs-classes-links"' }>
                            <span class="icon ion-ios-paper"></span>
                            <span>Classes</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="classes-links"' : 'id="xs-classes-links"' }>
                            <li class="link">
                                <a href="classes/AbstractBadgeComponent.html" data-type="entity-link">AbstractBadgeComponent</a>
                            </li>
                            <li class="link">
                                <a href="classes/AppIntegration.html" data-type="entity-link">AppIntegration</a>
                            </li>
                            <li class="link">
                                <a href="classes/AppIntegrationDetailComponent.html" data-type="entity-link">AppIntegrationDetailComponent</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadebookLti1Integration.html" data-type="entity-link">BadebookLti1Integration</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgeClass.html" data-type="entity-link">BadgeClass</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgeClassInstances.html" data-type="entity-link">BadgeClassInstances</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgeInstance.html" data-type="entity-link">BadgeInstance</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgeInstanceResultSet.html" data-type="entity-link">BadgeInstanceResultSet</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgeResult.html" data-type="entity-link">BadgeResult</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgeResult-1.html" data-type="entity-link">BadgeResult</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgeResult-2.html" data-type="entity-link">BadgeResult</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgrApiError.html" data-type="entity-link">BadgrApiError</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgrApiFailure.html" data-type="entity-link">BadgrApiFailure</a>
                            </li>
                            <li class="link">
                                <a href="classes/BadgrRouteReuseStrategy.html" data-type="entity-link">BadgrRouteReuseStrategy</a>
                            </li>
                            <li class="link">
                                <a href="classes/BaseAuthenticatedRoutableComponent.html" data-type="entity-link">BaseAuthenticatedRoutableComponent</a>
                            </li>
                            <li class="link">
                                <a href="classes/BaseDialog.html" data-type="entity-link">BaseDialog</a>
                            </li>
                            <li class="link">
                                <a href="classes/BaseRoutableComponent.html" data-type="entity-link">BaseRoutableComponent</a>
                            </li>
                            <li class="link">
                                <a href="classes/BidirectionallyLinkedEntitySet.html" data-type="entity-link">BidirectionallyLinkedEntitySet</a>
                            </li>
                            <li class="link">
                                <a href="classes/DateValidator.html" data-type="entity-link">DateValidator</a>
                            </li>
                            <li class="link">
                                <a href="classes/EmailValidator.html" data-type="entity-link">EmailValidator</a>
                            </li>
                            <li class="link">
                                <a href="classes/EmbeddedEntitySet.html" data-type="entity-link">EmbeddedEntitySet</a>
                            </li>
                            <li class="link">
                                <a href="classes/EntityLink.html" data-type="entity-link">EntityLink</a>
                            </li>
                            <li class="link">
                                <a href="classes/EntityRef.html" data-type="entity-link">EntityRef</a>
                            </li>
                            <li class="link">
                                <a href="classes/EntitySetUpdate.html" data-type="entity-link">EntitySetUpdate</a>
                            </li>
                            <li class="link">
                                <a href="classes/ExternalTool.html" data-type="entity-link">ExternalTool</a>
                            </li>
                            <li class="link">
                                <a href="classes/Issuer.html" data-type="entity-link">Issuer</a>
                            </li>
                            <li class="link">
                                <a href="classes/IssuerBadgesInfo.html" data-type="entity-link">IssuerBadgesInfo</a>
                            </li>
                            <li class="link">
                                <a href="classes/IssuerStaffMember.html" data-type="entity-link">IssuerStaffMember</a>
                            </li>
                            <li class="link">
                                <a href="classes/JsonValidator.html" data-type="entity-link">JsonValidator</a>
                            </li>
                            <li class="link">
                                <a href="classes/LazyEmbeddedEntitySet.html" data-type="entity-link">LazyEmbeddedEntitySet</a>
                            </li>
                            <li class="link">
                                <a href="classes/LinkedEntitySet.html" data-type="entity-link">LinkedEntitySet</a>
                            </li>
                            <li class="link">
                                <a href="classes/ListBackedEntitySet.html" data-type="entity-link">ListBackedEntitySet</a>
                            </li>
                            <li class="link">
                                <a href="classes/ListBackedLinkedEntitySet.html" data-type="entity-link">ListBackedLinkedEntitySet</a>
                            </li>
                            <li class="link">
                                <a href="classes/LoadableValueSubject.html" data-type="entity-link">LoadableValueSubject</a>
                            </li>
                            <li class="link">
                                <a href="classes/LoadedRouteParam.html" data-type="entity-link">LoadedRouteParam</a>
                            </li>
                            <li class="link">
                                <a href="classes/LoadingManagedEntity.html" data-type="entity-link">LoadingManagedEntity</a>
                            </li>
                            <li class="link">
                                <a href="classes/LoginPage.html" data-type="entity-link">LoginPage</a>
                            </li>
                            <li class="link">
                                <a href="classes/ManagedEntity.html" data-type="entity-link">ManagedEntity</a>
                            </li>
                            <li class="link">
                                <a href="classes/ManagedEntityGrouping.html" data-type="entity-link">ManagedEntityGrouping</a>
                            </li>
                            <li class="link">
                                <a href="classes/ManagedEntityMapping.html" data-type="entity-link">ManagedEntityMapping</a>
                            </li>
                            <li class="link">
                                <a href="classes/ManagedEntitySet.html" data-type="entity-link">ManagedEntitySet</a>
                            </li>
                            <li class="link">
                                <a href="classes/MatchingAlgorithm.html" data-type="entity-link">MatchingAlgorithm</a>
                            </li>
                            <li class="link">
                                <a href="classes/MatchingAlgorithm-1.html" data-type="entity-link">MatchingAlgorithm</a>
                            </li>
                            <li class="link">
                                <a href="classes/MatchingAlgorithm-2.html" data-type="entity-link">MatchingAlgorithm</a>
                            </li>
                            <li class="link">
                                <a href="classes/MatchingAlgorithm-3.html" data-type="entity-link">MatchingAlgorithm</a>
                            </li>
                            <li class="link">
                                <a href="classes/MatchingAlgorithm-4.html" data-type="entity-link">MatchingAlgorithm</a>
                            </li>
                            <li class="link">
                                <a href="classes/MatchingIssuerBadges.html" data-type="entity-link">MatchingIssuerBadges</a>
                            </li>
                            <li class="link">
                                <a href="classes/MatchingIssuerBadges-1.html" data-type="entity-link">MatchingIssuerBadges</a>
                            </li>
                            <li class="link">
                                <a href="classes/MatchingIssuerBadges-2.html" data-type="entity-link">MatchingIssuerBadges</a>
                            </li>
                            <li class="link">
                                <a href="classes/MdImgValidator.html" data-type="entity-link">MdImgValidator</a>
                            </li>
                            <li class="link">
                                <a href="classes/MutableEntityLink.html" data-type="entity-link">MutableEntityLink</a>
                            </li>
                            <li class="link">
                                <a href="classes/OAuth2AppAuthorization.html" data-type="entity-link">OAuth2AppAuthorization</a>
                            </li>
                            <li class="link">
                                <a href="classes/PaginationResults.html" data-type="entity-link">PaginationResults</a>
                            </li>
                            <li class="link">
                                <a href="classes/RecipientBadgeCollection.html" data-type="entity-link">RecipientBadgeCollection</a>
                            </li>
                            <li class="link">
                                <a href="classes/RecipientBadgeCollectionEntry.html" data-type="entity-link">RecipientBadgeCollectionEntry</a>
                            </li>
                            <li class="link">
                                <a href="classes/RecipientBadgeInstance.html" data-type="entity-link">RecipientBadgeInstance</a>
                            </li>
                            <li class="link">
                                <a href="classes/SignupModel.html" data-type="entity-link">SignupModel</a>
                            </li>
                            <li class="link">
                                <a href="classes/SignupPage.html" data-type="entity-link">SignupPage</a>
                            </li>
                            <li class="link">
                                <a href="classes/StandaloneEntitySet.html" data-type="entity-link">StandaloneEntitySet</a>
                            </li>
                            <li class="link">
                                <a href="classes/StringMatchingUtil.html" data-type="entity-link">StringMatchingUtil</a>
                            </li>
                            <li class="link">
                                <a href="classes/TelephoneValidator.html" data-type="entity-link">TelephoneValidator</a>
                            </li>
                            <li class="link">
                                <a href="classes/TypedFormArray.html" data-type="entity-link">TypedFormArray</a>
                            </li>
                            <li class="link">
                                <a href="classes/TypedFormControl.html" data-type="entity-link">TypedFormControl</a>
                            </li>
                            <li class="link">
                                <a href="classes/TypedFormGroup.html" data-type="entity-link">TypedFormGroup</a>
                            </li>
                            <li class="link">
                                <a href="classes/TypedFormItem.html" data-type="entity-link">TypedFormItem</a>
                            </li>
                            <li class="link">
                                <a href="classes/UnknownLti1Integration.html" data-type="entity-link">UnknownLti1Integration</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdatableSubject.html" data-type="entity-link">UpdatableSubject</a>
                            </li>
                            <li class="link">
                                <a href="classes/UrlValidator.html" data-type="entity-link">UrlValidator</a>
                            </li>
                            <li class="link">
                                <a href="classes/UserCredential.html" data-type="entity-link">UserCredential</a>
                            </li>
                            <li class="link">
                                <a href="classes/UserProfile.html" data-type="entity-link">UserProfile</a>
                            </li>
                            <li class="link">
                                <a href="classes/UserProfileEmail.html" data-type="entity-link">UserProfileEmail</a>
                            </li>
                            <li class="link">
                                <a href="classes/UserProfileSocialAccount.html" data-type="entity-link">UserProfileSocialAccount</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#injectables-links"' :
                                'data-target="#xs-injectables-links"' }>
                                <span class="icon ion-md-arrow-round-down"></span>
                                <span>Injectables</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                            <ul class="links collapse " ${ isNormalMode ? 'id="injectables-links"' : 'id="xs-injectables-links"' }>
                                <li class="link">
                                    <a href="injectables/AppConfigService.html" data-type="entity-link">AppConfigService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/BaseHttpApiService.html" data-type="entity-link">BaseHttpApiService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/CommonDialogsService.html" data-type="entity-link">CommonDialogsService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/EmbedService.html" data-type="entity-link">EmbedService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/EventsService.html" data-type="entity-link">EventsService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/ExternalToolsApiService.html" data-type="entity-link">ExternalToolsApiService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/ExternalToolsManager.html" data-type="entity-link">ExternalToolsManager</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/InitialLoadingIndicatorService.html" data-type="entity-link">InitialLoadingIndicatorService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/MessageService.html" data-type="entity-link">MessageService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/NavigationService.html" data-type="entity-link">NavigationService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/OAuthApiService.html" data-type="entity-link">OAuthApiService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/OAuthManager.html" data-type="entity-link">OAuthManager</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/QueryParametersService.html" data-type="entity-link">QueryParametersService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/SessionService.html" data-type="entity-link">SessionService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/SettingsService.html" data-type="entity-link">SettingsService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/SharingService.html" data-type="entity-link">SharingService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/ZipService.html" data-type="entity-link">ZipService</a>
                                </li>
                            </ul>
                        </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#guards-links"' :
                            'data-target="#xs-guards-links"' }>
                            <span class="icon ion-ios-lock"></span>
                            <span>Guards</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="guards-links"' : 'id="xs-guards-links"' }>
                            <li class="link">
                                <a href="guards/AuthGuard.html" data-type="entity-link">AuthGuard</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#interfaces-links"' :
                            'data-target="#xs-interfaces-links"' }>
                            <span class="icon ion-md-information-circle-outline"></span>
                            <span>Interfaces</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? ' id="interfaces-links"' : 'id="xs-interfaces-links"' }>
                            <li class="link">
                                <a href="interfaces/AddBadgeDialogOptions.html" data-type="entity-link">AddBadgeDialogOptions</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/AlignmentData.html" data-type="entity-link">AlignmentData</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiAppIntegration.html" data-type="entity-link">ApiAppIntegration</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiAppIntegrationRef.html" data-type="entity-link">ApiAppIntegrationRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgebookCanvasLti1AppIntegration.html" data-type="entity-link">ApiBadgebookCanvasLti1AppIntegration</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeClass.html" data-type="entity-link">ApiBadgeClass</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeClassAlignment.html" data-type="entity-link">ApiBadgeClassAlignment</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeClassExpiration.html" data-type="entity-link">ApiBadgeClassExpiration</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeClassForCreation.html" data-type="entity-link">ApiBadgeClassForCreation</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeClassJsonld.html" data-type="entity-link">ApiBadgeClassJsonld</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeInstance.html" data-type="entity-link">ApiBadgeInstance</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeInstanceEvidenceItem.html" data-type="entity-link">ApiBadgeInstanceEvidenceItem</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeInstanceForBatchCreation.html" data-type="entity-link">ApiBadgeInstanceForBatchCreation</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeInstanceForCreation.html" data-type="entity-link">ApiBadgeInstanceForCreation</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiBadgeInstanceJsonld.html" data-type="entity-link">ApiBadgeInstanceJsonld</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiEntityRef.html" data-type="entity-link">ApiEntityRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiExternalTool.html" data-type="entity-link">ApiExternalTool</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiExternalToolLaunchInfo.html" data-type="entity-link">ApiExternalToolLaunchInfo</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiExternalToolLaunchpoint.html" data-type="entity-link">ApiExternalToolLaunchpoint</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiIssuer.html" data-type="entity-link">ApiIssuer</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiIssuerForCreation.html" data-type="entity-link">ApiIssuerForCreation</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiIssuerForEditing.html" data-type="entity-link">ApiIssuerForEditing</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiIssuerJsonld.html" data-type="entity-link">ApiIssuerJsonld</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiIssuerStaff.html" data-type="entity-link">ApiIssuerStaff</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiIssuerStaffOperation.html" data-type="entity-link">ApiIssuerStaffOperation</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiOAuth2AppAuthorization.html" data-type="entity-link">ApiOAuth2AppAuthorization</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiOAuth2AppInfo.html" data-type="entity-link">ApiOAuth2AppInfo</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiOAuth2ClientAuthorized.html" data-type="entity-link">ApiOAuth2ClientAuthorized</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiOAuthApplication.html" data-type="entity-link">ApiOAuthApplication</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiRecipientBadgeClass.html" data-type="entity-link">ApiRecipientBadgeClass</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiRecipientBadgeCollection.html" data-type="entity-link">ApiRecipientBadgeCollection</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiRecipientBadgeCollectionEntry.html" data-type="entity-link">ApiRecipientBadgeCollectionEntry</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiRecipientBadgeCollectionForCreation.html" data-type="entity-link">ApiRecipientBadgeCollectionForCreation</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiRecipientBadgeInstance.html" data-type="entity-link">ApiRecipientBadgeInstance</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiRecipientBadgeInstanceJson.html" data-type="entity-link">ApiRecipientBadgeInstanceJson</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiRecipientBadgeIssuer.html" data-type="entity-link">ApiRecipientBadgeIssuer</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiRecipientBadgeRecipient.html" data-type="entity-link">ApiRecipientBadgeRecipient</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiUserProfile.html" data-type="entity-link">ApiUserProfile</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiUserProfileEmail.html" data-type="entity-link">ApiUserProfileEmail</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiUserProfileSocialAccount.html" data-type="entity-link">ApiUserProfileSocialAccount</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiV2Status.html" data-type="entity-link">ApiV2Status</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ApiV2Wrapper.html" data-type="entity-link">ApiV2Wrapper</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/AuthorizationToken.html" data-type="entity-link">AuthorizationToken</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BadgeClassEditForm.html" data-type="entity-link">BadgeClassEditForm</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BadgeClassRef.html" data-type="entity-link">BadgeClassRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BadgeInstanceBatchAssertion.html" data-type="entity-link">BadgeInstanceBatchAssertion</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BadgeInstanceRef.html" data-type="entity-link">BadgeInstanceRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BadgeLookupData.html" data-type="entity-link">BadgeLookupData</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BadgeSelectionDialogOptions.html" data-type="entity-link">BadgeSelectionDialogOptions</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BadgeSelectionDialogSettings.html" data-type="entity-link">BadgeSelectionDialogSettings</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BadgeShareOptions.html" data-type="entity-link">BadgeShareOptions</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BadgrRouteData.html" data-type="entity-link">BadgrRouteData</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BulkIssueData.html" data-type="entity-link">BulkIssueData</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BulkIssueImportPreviewData.html" data-type="entity-link">BulkIssueImportPreviewData</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ColumnHeaders.html" data-type="entity-link">ColumnHeaders</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ConfirmDialogOptions.html" data-type="entity-link">ConfirmDialogOptions</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/CreateBadgeCollectionForm.html" data-type="entity-link">CreateBadgeCollectionForm</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/EntitySet.html" data-type="entity-link">EntitySet</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ExternalAuthProvider.html" data-type="entity-link">ExternalAuthProvider</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ExternalToolRef.html" data-type="entity-link">ExternalToolRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/FlashMessage.html" data-type="entity-link">FlashMessage</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/FormFieldSelectOption.html" data-type="entity-link">FormFieldSelectOption</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/GroupedPair.html" data-type="entity-link">GroupedPair</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ImportCsvForm.html" data-type="entity-link">ImportCsvForm</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ImportCsvForm-1.html" data-type="entity-link">ImportCsvForm</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/IssuerRef.html" data-type="entity-link">IssuerRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/IssuerStaffRef.html" data-type="entity-link">IssuerStaffRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/LinkEntry.html" data-type="entity-link">LinkEntry</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/MatrixColor.html" data-type="entity-link">MatrixColor</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/Notification.html" data-type="entity-link">Notification</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/OAuth2AppAuthorizationRef.html" data-type="entity-link">OAuth2AppAuthorizationRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/OAuth2RequestParams.html" data-type="entity-link">OAuth2RequestParams</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/OAuthState.html" data-type="entity-link">OAuthState</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/PromiseOwnership.html" data-type="entity-link">PromiseOwnership</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/PublicApiBadgeAssertion.html" data-type="entity-link">PublicApiBadgeAssertion</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/PublicApiBadgeAssertionWithBadgeClass.html" data-type="entity-link">PublicApiBadgeAssertionWithBadgeClass</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/PublicApiBadgeClass.html" data-type="entity-link">PublicApiBadgeClass</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/PublicApiBadgeClassWithIssuer.html" data-type="entity-link">PublicApiBadgeClassWithIssuer</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/PublicApiBadgeCollectionEntryWithBadgeClassAndIssuer.html" data-type="entity-link">PublicApiBadgeCollectionEntryWithBadgeClassAndIssuer</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/PublicApiBadgeCollectionWithBadgeClassAndIssuer.html" data-type="entity-link">PublicApiBadgeCollectionWithBadgeClassAndIssuer</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/PublicApiIssuer.html" data-type="entity-link">PublicApiIssuer</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeClassRef.html" data-type="entity-link">RecipientBadgeClassRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeCollectionEntryRef.html" data-type="entity-link">RecipientBadgeCollectionEntryRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeCollectionRef.html" data-type="entity-link">RecipientBadgeCollectionRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeCollectionSelectionDialogOptions.html" data-type="entity-link">RecipientBadgeCollectionSelectionDialogOptions</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeInstanceFromHostedUrl.html" data-type="entity-link">RecipientBadgeInstanceFromHostedUrl</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeInstanceFromImage.html" data-type="entity-link">RecipientBadgeInstanceFromImage</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeInstanceFromJson.html" data-type="entity-link">RecipientBadgeInstanceFromJson</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeInstanceRef.html" data-type="entity-link">RecipientBadgeInstanceRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeSelectionDialogOptions.html" data-type="entity-link">RecipientBadgeSelectionDialogOptions</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RecipientBadgeSelectionDialogSettings.html" data-type="entity-link">RecipientBadgeSelectionDialogSettings</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ScopeGroupRule.html" data-type="entity-link">ScopeGroupRule</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ServerError.html" data-type="entity-link">ServerError</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ShareSocialDialogEmbedOption.html" data-type="entity-link">ShareSocialDialogEmbedOption</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ShareSocialDialogOptions.html" data-type="entity-link">ShareSocialDialogOptions</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/SocialAccountProviderInfo.html" data-type="entity-link">SocialAccountProviderInfo</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/TransformedImportData.html" data-type="entity-link">TransformedImportData</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/UnverifiedEmail.html" data-type="entity-link">UnverifiedEmail</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/UserProfileEmailRef.html" data-type="entity-link">UserProfileEmailRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/UserProfileRef.html" data-type="entity-link">UserProfileRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/UserProfileSocialAccountRef.html" data-type="entity-link">UserProfileSocialAccountRef</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ValidationResult.html" data-type="entity-link">ValidationResult</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ValidationResult-1.html" data-type="entity-link">ValidationResult</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/VisualCenterCoords.html" data-type="entity-link">VisualCenterCoords</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/VisualCenterResult.html" data-type="entity-link">VisualCenterResult</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ZipEntry.html" data-type="entity-link">ZipEntry</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ZipTask.html" data-type="entity-link">ZipTask</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ZipTaskProgress.html" data-type="entity-link">ZipTaskProgress</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#miscellaneous-links"'
                            : 'data-target="#xs-miscellaneous-links"' }>
                            <span class="icon ion-ios-cube"></span>
                            <span>Miscellaneous</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="miscellaneous-links"' : 'id="xs-miscellaneous-links"' }>
                            <li class="link">
                                <a href="miscellaneous/enumerations.html" data-type="entity-link">Enums</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/functions.html" data-type="entity-link">Functions</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/typealiases.html" data-type="entity-link">Type aliases</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/variables.html" data-type="entity-link">Variables</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <a data-type="chapter-link" href="routes.html"><span class="icon ion-ios-git-branch"></span>Routes</a>
                        </li>
                    <li class="chapter">
                        <a data-type="chapter-link" href="coverage.html"><span class="icon ion-ios-stats"></span>Documentation coverage</a>
                    </li>
                    <li class="divider"></li>
                    <li class="copyright">
                        Documentation generated using <a href="https://compodoc.app/" target="_blank">
                            <img data-src="images/compodoc-vectorise.png" class="img-responsive" data-type="compodoc-logo">
                        </a>
                    </li>
            </ul>
        </nav>
        `);
        this.innerHTML = tp.strings;
    }
});